return
{
    keymaps = {
        normal = "<leader>s",
        normal_cur = "<leader>ss",
        normal_line = "<leader>S",
        normal_cur_line = "<leader>SS",
        delete = "d<leader>",
        change = "c<leader>",
    },
    move_cursor = "sticky",
}
